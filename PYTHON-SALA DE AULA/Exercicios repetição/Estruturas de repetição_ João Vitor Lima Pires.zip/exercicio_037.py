# n = int ( input ('Qual tabuada deseja ? '))

# for i in range(1, 11):
#    print (f'{n} x {i} = {n * i}') 

n = int(input('Qual tabuada deseja ? '))
c = 1
while c <= 10:
    print (f'{n} x {c} = {n * c}')
    c += 1 
