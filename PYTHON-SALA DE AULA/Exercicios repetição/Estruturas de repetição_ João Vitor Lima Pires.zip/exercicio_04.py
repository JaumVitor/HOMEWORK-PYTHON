valor = int ( input ('Digite o valor: '))
resultado = valor

while resultado > 1:
    print (resultado)
    resultado = resultado // 2
    