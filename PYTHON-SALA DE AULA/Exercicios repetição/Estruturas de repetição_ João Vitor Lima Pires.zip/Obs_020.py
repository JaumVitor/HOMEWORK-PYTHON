chegada = 600
tanque = 50
soma_percurso = 0

while soma_percurso <= 600: 
    km = int(input('Quantos quilômetros foram percorridos ? '))
    soma_percurso += km 
